import {hyronEditDriveCode,hyronIsEditableCode} from './code-editor.js'; // HYRON_CODE_EDITOR_081
import {hyronConfirm} from "./hyron-dialogs.js";
import {createAttachmentCard} from './attachment-cards.js'; // HYRON_V067_ATTACHMENT_CARDS
import './file-preview.js'; // HYRON_PREVIEW_V066
// HYRON_GOOGLE_DRIVE_UI_V063B
window.addEventListener("hyron-drive-file-updated",()=>{if(!document.getElementById("hyron-drive-panel")?.hidden)void refresh();});
const q=id=>document.getElementById(id);
const note=q('hyron-drive-status'),list=q('hyron-drive-list'),pick=q('hyron-drive-picker');
const drivePreviewUrl=f=>/\.(png|jpe?g|webp|gif|svg)$/i.test(String(f.name||'')) && Number(f.size)>0 && Number(f.size)<=8*1048576 && /^[A-Za-z0-9_-]{8,180}$/.test(String(f.id||'')) ? '/api/drive/files/'+encodeURIComponent(f.id)+'/preview' : '';
const fmt=n=>Number(n)>1048576?(Number(n)/1048576).toFixed(1)+' MB':Math.ceil(Number(n)/1024)+' KB';
async function api(url,init={}){const r=await fetch(url,{credentials:'same-origin',...init});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'HTTP '+r.status);return d;}
const post=(p,b={})=>api(p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});
async function refresh(){try{const s=await api('/api/drive/status');q('hyron-drive-connect').hidden=s.connected;q('hyron-drive-disconnect').hidden=!s.connected;pick.hidden=!s.connected;q('hyron-drive-head').textContent=s.connected?'Google Drive conectado':'Google Drive desconectado';list.replaceChildren();if(!s.connected)return;
 const x=await api('/api/drive/files');if(!x.files.length){list.textContent='Nenhum arquivo enviado pelo HYRON.';return;}
 for(const file of x.files){const row=document.createElement('div');row.className='hyron-file-row';const card=createAttachmentCard({name:file.name,size:file.size,previewUrl:drivePreviewUrl(file),variant:'drive',onOpen:()=>window.hyronPreviewDriveFile?.(file)});const a=document.createElement('a');a.textContent='Baixar';a.href='/api/drive/files/'+encodeURIComponent(file.id)+'/download';const del=document.createElement('button');del.type='button';del.textContent='Excluir';del.addEventListener('click',async()=>{if(!await hyronConfirm('Excluir permanentemente '+file.name+' do seu Google Drive?'))return;try{await api('/api/drive/files/'+encodeURIComponent(file.id),{method:'DELETE',headers:{'content-type':'application/json'}});await refresh();}catch(e){note.textContent=e.message;}});const actions=document.createElement('div');actions.className='hyron-drive-actions';if(hyronIsEditableCode(file.name)){const edit=document.createElement('button');edit.type='button';edit.textContent='Editar';edit.onclick=()=>hyronEditDriveCode(file).catch(e=>{note.textContent=String(e.message||e)});actions.append(edit);}actions.append(a,del);row.append(card,actions);list.append(row);}
 }catch(e){note.textContent='Drive: '+e.message;}}
q('hyron-drive-connect')?.addEventListener('click',()=>location.assign('/api/drive/connect'));
q('hyron-drive-disconnect')?.addEventListener('click',async()=>{if(!await hyronConfirm('Desconectar Google Drive? Os arquivos enviados permanecerão no Drive.'))return;try{await post('/api/drive/disconnect');note.textContent='Conta desconectada.';await refresh();}catch(e){note.textContent=e.message;}});
q('hyron-drive-open')?.addEventListener('click',async()=>{const p=q('hyron-drive-panel');p.hidden=!p.hidden;if(!p.hidden)await refresh();});
q('hyron-drive-close')?.addEventListener('click',()=>q('hyron-drive-panel').hidden=true);
pick?.addEventListener('change',async()=>{const selected=Array.from(pick.files||[]);pick.value='';for(const file of selected){if(file.size<1||file.size>100*1024*1024){note.textContent='Tamanho permitido: 1 byte a 100 MB';continue;}
 try{note.textContent='Preparando '+file.name;const s=await post('/api/drive/upload/start',{name:file.name,size:file.size,mime:(file.type||'application/octet-stream').split(';',1)[0].trim().toLowerCase()||'application/octet-stream' /* HYRON_082_MEDIA_MIME_NORMALIZE */});let offset=0;while(offset<file.size){const end=Math.min(file.size,offset+s.partSize),blob=file.slice(offset,end);const r=await fetch('/api/drive/upload/'+s.id+'/part',{method:'PUT',credentials:'same-origin',headers:{'content-type':'application/octet-stream'},body:blob});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Falha no envio');offset=end;note.textContent=file.name+' · '+Math.floor(offset/file.size*100)+'%';if(d.done)break;}note.textContent='Enviado ao Google Drive: '+file.name;await refresh();}catch(e){note.textContent='Erro: '+e.message;}
 }});
if(new URLSearchParams(location.search).has('drive')){const u=new URL(location.href);u.searchParams.delete('drive');history.replaceState(null,'',u.pathname+u.search+u.hash);q('hyron-drive-panel').hidden=false;refresh();}

// HYRON_DRIVE_DELETE_CONTENT_TYPE_V063G

// HYRON_V064_DRIVE_ATTACH: reusa o upload autenticado para anexos do chat.
window.hyronDriveStatus=async()=>{
 try {const x=await api('/api/drive/status');return !!x.connected;}catch{return false;}
};
window.hyronDriveUploadFile=async(file,onProgress=()=>{})=>{
 if(!file||file.size<1||file.size>100*1024*1024)throw Error('Google Drive aceita arquivos de 1 byte até 100 MB.');
 const start=await post('/api/drive/upload/start',{name:file.name,size:file.size,mime:(file.type||'application/octet-stream').split(';',1)[0].trim().toLowerCase()||'application/octet-stream' /* HYRON_082_MEDIA_MIME_NORMALIZE */});
 let offset=0;
 while(offset<file.size){
  const end=Math.min(file.size,offset+start.partSize);
  const response=await fetch('/api/drive/upload/'+encodeURIComponent(start.id)+'/part',{
   method:'PUT',credentials:'same-origin',headers:{'content-type':'application/octet-stream'},body:file.slice(offset,end)
  });
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw Error(data.error||'Google Drive HTTP '+response.status);
  offset=end;onProgress(Math.floor(100*offset/file.size));
  if(data.done)return {id:data.id||'',name:file.name,size:file.size};
 }
 throw Error('Upload do Google Drive não foi concluído.');
};

// HYRON_V065_DRIVE_PICKER: selecionar imagens previamente enviadas ao Drive do próprio usuário.
(()=>{
 const anchor=document.getElementById('hyron-attach-button');if(!anchor)return;
 const button=document.createElement('button');button.type='button';button.textContent='📂 Do Drive';button.title='Selecionar imagens e textos salvos no Google Drive conectado';button.id='hyron-drive-image-attach';
 anchor.after(button);
 const pane=document.createElement('div');pane.id='hyron-drive-image-list';pane.hidden=true;
 pane.style.cssText='padding:10px;max-height:240px;overflow:auto;border:1px solid #376e5e;border-radius:9px;margin:5px 0;';
 document.getElementById('hyron-attach-strip')?.before(pane);
 button.addEventListener('click',async()=>{
  pane.hidden=!pane.hidden;if(pane.hidden)return;
  pane.textContent='Carregando arquivos privados do Google Drive...';
  try{
   const x=await api('/api/drive/files');pane.replaceChildren();
   const extensions=new Set(['txt','md','markdown','html','htm','css','js','mjs','cjs','jsx','ts','tsx','py','php','java','cs','c','h','cpp','hpp','go','rs','rb','sh','bat','ps1','sql','json','jsonc','xml','yaml','yml','toml','ini','cfg','env','csv','tsv','log','svg','vue','svelte','gradle','gitignore','pdf','docx','pptx','png','jpg','jpeg','webp']);
   const items=(x.files||[]).filter(f=>extensions.has(String(f.name||'').toLowerCase().split('.').pop()) && Number(f.size)>0 && Number(f.size)<=100*1024*1024);
   if(!items.length){pane.textContent='Nenhum texto, documento ou imagem compatível na pasta HYRON do seu Drive.';return;}
   for(const img of items){const tile=document.createElement('div');tile.className='hyron-drive-select-item';const b=document.createElement('button');b.type='button';b.className='hyron-drive-select-action';b.textContent='📎 '+img.name+' ('+fmt(img.size)+')';b.style.cssText='display:block;margin:5px 0;max-width:100%;overflow-wrap:anywhere;';
    const pv=createAttachmentCard({name:img.name,size:img.size,previewUrl:drivePreviewUrl(img),variant:'drive',onOpen:()=>window.hyronPreviewDriveFile?.(img)});tile.append(pv);if(hyronIsEditableCode(img.name)){const edit=document.createElement('button');edit.type='button';edit.textContent='Editar';edit.onclick=()=>hyronEditDriveCode(img).catch(e=>{pane.textContent=String(e.message||e)});tile.append(edit);}
    b.onclick=async()=>{b.disabled=true;b.textContent='Baixando '+img.name+'...';
     try{
      const r=await fetch('/api/drive/files/'+encodeURIComponent(img.id)+'/download',{credentials:'same-origin',cache:'no-store'});
      if(!r.ok)throw Error((await r.json().catch(()=>({}))).error||'HTTP '+r.status);
      const blob=await r.blob();if(blob.size>100*1024*1024)throw Error('Arquivo acima de 100 MB');
      const file=new File([blob],img.name,{type:img.mimeType});window.hyronAttachDriveFile(file,img.id);pane.hidden=true;
     }catch(e){b.textContent='Falha: '+String(e.message||e);b.disabled=false;}
    };tile.append(b);pane.append(tile);
   }
  }catch(e){pane.textContent='Não foi possível listar imagens: '+String(e.message||e);}
 });
})();
